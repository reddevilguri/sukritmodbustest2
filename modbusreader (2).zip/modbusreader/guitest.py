import tkinter as tk
from easymodbus.modbusClient import *

#make changes to the function



def readdiscreteinput():
 discreteInputs = modbusclient.read_discreteinputs(ent_discreteinputstrtaddr, ent_discreteinputqty)
 lbl_rdiscreteinput["text"]=discreteInputs

def readinputregister():
 inputRegisters = modbusclient.read_inputregisters(ent_inputregisterstrtaddr, ent_inputregisterqty)
 lbl_rinputregister["text"]=inputRegisters


window = tk.Tk()
window.title("Modbus Test")

#create button to get IP

window.resizable(width=False, height=False)
frm_entry = tk.Frame(master=window)
ent_ip = tk.Entry(master=frm_entry, width=20)
lbl_ip = tk.Label(master=frm_entry, text="Enter IP")

ent_ip.grid(row=0, column=1)
lbl_ip.grid(row=0, column=0)



# Create the conversion Button and result display Label
btn_submit = tk.Button(
    master=frm_entry,
    text="Connect",
    command=ent_ip.get
)

lbl_result = tk.Label(master=frm_entry)

#connect to modbus device
modbusclient = ModbusClient(ent_ip.get, 502)
modbusclient.parity = Parity.even
modbusclient.unitidentifier = 2
modbusclient.baudrate = 9600
modbusclient.stopbits = Stopbits.one
modbusclient.connect()

#Read discrete inputs
frm_discreteinput=tk.Frame(master=window)
lbl_discreteinput=tk.Label(master=frm_discreteinput, text="Read discrete inputs")
lbl_rdiscreteinput=tk.Label(master=frm_discreteinput)
lbl_discreteinputstrtaddr=tk.Label(master=frm_discreteinput, text="Give start address")
ent_discreteinputstrtaddr=tk.Entry(master=frm_discreteinput)
lbl_discreteinputqty=tk.Label(master=frm_discreteinput, text="Give quantity")
ent_discreteinputqty=tk.Entry(master=frm_discreteinput)

btn_discreteinput=tk.Button(master=frm_discreteinput,
                            text="Get discrete Input",
                            command=readdiscreteinput)


#Read input register
frm_inputregister=tk.Frame(master=window)
lbl_inputregister=tk.Label(master=frm_discreteinput, text="Read input register")
lbl_rinputregister=tk.Label(master=frm_discreteinput)
lbl_inputregisterstrtaddr=tk.Label(master=frm_discreteinput, text="Give start address")
ent_inputregisterstrtaddr=tk.Entry(master=frm_discreteinput)
lbl_inputregisterqty=tk.Label(master=frm_discreteinput, text="Give quantity")
ent_inputregisterqty=tk.Entry(master=frm_discreteinput)


btn_inputregister=tk.Button(master=frm_discreteinput,
                            text="Get Input Register",
                            command=readinputregister)


# Set-up the layout using the .grid() geometry manager
frm_entry.grid(row=0, column=0, padx=10)
btn_submit.grid(row=0, column=2, padx=10)
lbl_result.grid(row=0, column=3, padx=10)

frm_discreteinput.grid(row=1, column=0, padx=10)
lbl_discreteinput.grid(row=1, column=1, padx=10)
lbl_discreteinputstrtaddr.grid(row=2, column=0, padx=10)
ent_discreteinputstrtaddr.grid(row=2, column=1, padx=10)
lbl_discreteinputqty.grid(row=2, column=2, padx=10)
ent_discreteinputqty.grid(row=2, column=3, padx=10)
btn_discreteinput.grid(row=2, column=4, padx=10)
lbl_rdiscreteinput.grid(row=2, column=5, padx=10)

frm_inputregister.grid(row=3, column=0, padx=10)
lbl_inputregister.grid(row=3, column=1, padx=10)
lbl_inputregisterstrtaddr.grid(row=4, column=0, padx=10)
ent_inputregisterstrtaddr.grid(row=4, column=1, padx=10)
lbl_inputregisterqty.grid(row=4, column=2, padx=10)
ent_inputregisterqty.grid(row=4, column=3, padx=10)
btn_inputregister.grid(row=4, column=4, padx=10)
lbl_rinputregister.grid(row=4, column=5, padx=10)

# Run the application

modbusclient.close()
window.mainloop()
